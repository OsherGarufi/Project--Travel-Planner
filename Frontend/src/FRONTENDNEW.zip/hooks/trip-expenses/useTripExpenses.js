import {
  useEffect,
  useRef,
  useState,
} from 'react'
import {
  clearCachedTripExpenses,
  getCachedTripExpenses,
  getTripExpensesCacheKey,
  setCachedTripExpenses,
  syncCachedTripExpensesFromStorage,
} from '../../services/expenseCacheService'
import {
  createTripExpense,
  deleteTripExpense,
  getTripExpenses,
  updateTripExpense,
} from '../../services/expenseService'
import {
  getTripItineraryCache,
  setTripItineraryCache,
} from '../../services/itinerary/itineraryCache'
import {
  syncExpensesCacheFromItineraryItem,
  syncItineraryCacheAfterExpenseDelete,
  syncItineraryCacheFromExpense,
} from '../../services/itinerary/itineraryExpenseCacheSync'
import {
  createTripItineraryItem,
} from '../../services/itinerary/itineraryService'
import {
  getOrCreateTripExpensesRequest,
  releaseTripExpensesRequest,
} from '../../services/trips/tripsRequestManager'
import { useAuth } from '../useAuth'

export function useTripExpenses(
  tripId,
) {
  const {
    firebaseUser,
    idToken,
  } = useAuth()

  const userId =
    firebaseUser?.uid ?? null

  const expensesContextKey =
    userId && tripId
      ? `${userId}:${tripId}`
      : null

  const [
    expenses,
    setExpenses,
  ] = useState([])

  const expensesRef =
    useRef([])

  const [
    loadedContextKey,
    setLoadedContextKey,
  ] = useState(null)

  const [
    reloadVersion,
    setReloadVersion,
  ] = useState(0)

  const [
    expensesError,
    setExpensesError,
  ] = useState('')

  const [
    expenseActionError,
    setExpenseActionError,
  ] = useState('')

  const [
    isCreatingExpense,
    setIsCreatingExpense,
  ] = useState(false)

  const [
    updatingExpenseId,
    setUpdatingExpenseId,
  ] = useState(null)

  const [
    deletingExpenseId,
    setDeletingExpenseId,
  ] = useState(null)

  const applyExpenses = (
    nextExpenses,
  ) => {
    expensesRef.current =
      nextExpenses

    setExpenses(
      nextExpenses,
    )

    if (
      userId &&
      tripId
    ) {
      setCachedTripExpenses(
        userId,
        tripId,
        nextExpenses,
      )
    }
  }

  useEffect(() => {
    if (
      !tripId ||
      !userId ||
      !idToken ||
      !expensesContextKey
    ) {
      expensesRef.current = []

      setExpenses([])
      setLoadedContextKey(null)
      setExpensesError('')

      return undefined
    }

    let isActive = true
    let expensesRequest = null

    const loadExpenses =
      async () => {
        await Promise.resolve()

        if (!isActive) {
          return
        }

        const cachedExpenses =
          getCachedTripExpenses(
            userId,
            tripId,
          )

        if (
          Array.isArray(
            cachedExpenses,
          )
        ) {
          expensesRef.current =
            cachedExpenses

          setExpenses(
            cachedExpenses,
          )

          setExpensesError('')

          setLoadedContextKey(
            expensesContextKey,
          )

          return
        }

        expensesRef.current = []

        setExpenses([])
        setLoadedContextKey(null)
        setExpensesError('')

        expensesRequest =
          getOrCreateTripExpensesRequest(
            userId,
            tripId,
            () =>
              getTripExpenses(
                tripId,
                idToken,
              ),
          )

        try {
          const result =
            await expensesRequest

          if (!isActive) {
            return
          }

          const loadedExpenses =
            Array.isArray(result)
              ? result
              : []

          expensesRef.current =
            loadedExpenses

          setExpenses(
            loadedExpenses,
          )

          setCachedTripExpenses(
            userId,
            tripId,
            loadedExpenses,
          )

          setExpensesError('')

          setLoadedContextKey(
            expensesContextKey,
          )
        } catch (error) {
          if (!isActive) {
            return
          }

          console.error(
            'Failed to load trip expenses:',
            error,
          )

          expensesRef.current = []

          setExpenses([])

          setExpensesError(
            'Could not load trip expenses. Please try again.',
          )

          setLoadedContextKey(
            expensesContextKey,
          )
        } finally {
          if (expensesRequest) {
            releaseTripExpensesRequest(
              userId,
              tripId,
              expensesRequest,
            )
          }
        }
      }

    loadExpenses()

    return () => {
      isActive = false
    }
  }, [
    tripId,
    userId,
    idToken,
    expensesContextKey,
    reloadVersion,
  ])

  useEffect(() => {
    if (
      !userId ||
      !tripId ||
      !expensesContextKey ||
      loadedContextKey !==
        expensesContextKey
    ) {
      return undefined
    }

    const cacheKey =
      getTripExpensesCacheKey(
        userId,
        tripId,
      )

    const handleStorageChange = (
      event,
    ) => {
      if (
        event.storageArea !==
          localStorage ||
        event.key !== cacheKey ||
        !event.newValue
      ) {
        return
      }

      const nextExpenses =
        syncCachedTripExpensesFromStorage(
          userId,
          tripId,
          event.newValue,
        )

      if (
        !Array.isArray(
          nextExpenses,
        )
      ) {
        return
      }

      expensesRef.current =
        nextExpenses

      setExpenses(
        nextExpenses,
      )

      setExpensesError('')
    }

    window.addEventListener(
      'storage',
      handleStorageChange,
    )

    return () => {
      window.removeEventListener(
        'storage',
        handleStorageChange,
      )
    }
  }, [
    userId,
    tripId,
    expensesContextKey,
    loadedContextKey,
  ])

  const hasExpensesContext =
    Boolean(
      tripId &&
      userId &&
      idToken &&
      expensesContextKey,
    )

  const isLoadingExpenses =
    Boolean(
      hasExpensesContext &&
      loadedContextKey !==
        expensesContextKey,
    )

  const visibleExpenses =
    hasExpensesContext &&
    loadedContextKey ===
      expensesContextKey
      ? expenses
      : []

  const reloadExpenses = () => {
    if (
      !tripId ||
      !userId ||
      !idToken
    ) {
      return
    }

    clearCachedTripExpenses(
      userId,
      tripId,
    )

    expensesRef.current = []

    setExpenses([])
    setExpensesError('')
    setLoadedContextKey(null)

    setReloadVersion(
      (currentVersion) =>
        currentVersion + 1,
    )
  }

  const addExpense = async (
    expenseData,
  ) => {
    if (
      !tripId ||
      !userId ||
      !idToken ||
      loadedContextKey !==
        expensesContextKey ||
      isCreatingExpense
    ) {
      return null
    }

    try {
      setIsCreatingExpense(true)
      setExpenseActionError('')

      const createdExpense =
        await createTripExpense(
          tripId,
          expenseData,
          idToken,
        )

      if (!createdExpense?.id) {
        throw new Error(
          'Invalid expense response.',
        )
      }

      const nextExpenses = [
        createdExpense,
        ...expensesRef.current,
      ]

      applyExpenses(
        nextExpenses,
      )

      syncItineraryCacheFromExpense(
        userId,
        tripId,
        createdExpense,
      )

      return createdExpense
    } catch (error) {
      console.error(
        'Failed to create trip expense:',
        error,
      )

      setExpenseActionError(
        'Could not add the expense. Please try again.',
      )

      return null
    } finally {
      setIsCreatingExpense(false)
    }
  }

  const addExpenseActivity =
    async (itemData) => {
      if (
        !tripId ||
        !userId ||
        !idToken ||
        loadedContextKey !==
          expensesContextKey ||
        isCreatingExpense
      ) {
        return null
      }

      try {
        setIsCreatingExpense(true)
        setExpenseActionError('')

        const createdItem =
          await createTripItineraryItem(
            tripId,
            itemData,
            idToken,
          )

        if (
          !createdItem?.id ||
          !createdItem?.expenseId
        ) {
          throw new Error(
            'Invalid linked activity response.',
          )
        }

        const cachedItineraryItems =
          getTripItineraryCache(
            userId,
            tripId,
          )

        if (
          Array.isArray(
            cachedItineraryItems,
          )
        ) {
          const hasCreatedItem =
            cachedItineraryItems.some(
              (item) =>
                item.id ===
                createdItem.id,
            )

          const nextItineraryItems =
            hasCreatedItem
              ? cachedItineraryItems.map(
                  (item) =>
                    item.id ===
                    createdItem.id
                      ? createdItem
                      : item,
                )
              : [
                  ...cachedItineraryItems,
                  createdItem,
                ]

          setTripItineraryCache(
            userId,
            tripId,
            nextItineraryItems,
          )
        }

        syncExpensesCacheFromItineraryItem(
          userId,
          tripId,
          createdItem,
        )

        const nextExpenses =
          getCachedTripExpenses(
            userId,
            tripId,
          )

        if (
          !Array.isArray(
            nextExpenses,
          )
        ) {
          throw new Error(
            'Could not synchronize the expense cache.',
          )
        }

        expensesRef.current =
          nextExpenses

        setExpenses(
          nextExpenses,
        )

        return createdItem
      } catch (error) {
        console.error(
          'Failed to create linked trip activity:',
          error,
        )

        setExpenseActionError(
          'Could not add the trip item. Please try again.',
        )

        return null
      } finally {
        setIsCreatingExpense(false)
      }
    }

  const editExpense = async (
    expenseId,
    expenseData,
  ) => {
    if (
      !tripId ||
      !userId ||
      !expenseId ||
      !idToken ||
      loadedContextKey !==
        expensesContextKey ||
      updatingExpenseId
    ) {
      return null
    }

    try {
      setUpdatingExpenseId(
        expenseId,
      )

      setExpenseActionError('')

      const updatedExpense =
        await updateTripExpense(
          tripId,
          expenseId,
          expenseData,
          idToken,
        )

      if (!updatedExpense?.id) {
        throw new Error(
          'Invalid expense response.',
        )
      }

      const nextExpenses =
        expensesRef.current.map(
          (expense) =>
            expense.id ===
            expenseId
              ? updatedExpense
              : expense,
        )

      applyExpenses(
        nextExpenses,
      )

      syncItineraryCacheFromExpense(
        userId,
        tripId,
        updatedExpense,
      )

      return updatedExpense
    } catch (error) {
      console.error(
        'Failed to update trip expense:',
        error,
      )

      setExpenseActionError(
        'Could not update the expense. Please try again.',
      )

      return null
    } finally {
      setUpdatingExpenseId(null)
    }
  }

  const removeExpense = async (
    expenseId,
    deleteLinkedActivity = null,
  ) => {
    if (
      !tripId ||
      !userId ||
      !expenseId ||
      !idToken ||
      loadedContextKey !==
        expensesContextKey ||
      deletingExpenseId
    ) {
      return false
    }

    const expenseToDelete =
      expensesRef.current.find(
        (expense) =>
          expense.id ===
          expenseId,
      )

    try {
      setDeletingExpenseId(
        expenseId,
      )

      setExpenseActionError('')

      await deleteTripExpense(
        tripId,
        expenseId,
        idToken,
        deleteLinkedActivity,
      )

      const nextExpenses =
        expensesRef.current.filter(
          (expense) =>
            expense.id !==
            expenseId,
        )

      applyExpenses(
        nextExpenses,
      )

      if (expenseToDelete) {
        syncItineraryCacheAfterExpenseDelete(
          userId,
          tripId,
          expenseToDelete,
          deleteLinkedActivity,
        )
      }

      return true
    } catch (error) {
      console.error(
        'Failed to delete trip expense:',
        error,
      )

      setExpenseActionError(
        'Could not delete the expense. Please try again.',
      )

      return false
    } finally {
      setDeletingExpenseId(null)
    }
  }

  const clearExpenseActionError =
    () => {
      setExpenseActionError('')
    }

  return {
    expenses:
      visibleExpenses,

    isLoadingExpenses,
    expensesError,
    expenseActionError,

    isCreatingExpense,
    updatingExpenseId,
    deletingExpenseId,

    reloadExpenses,

    addExpense,
    addExpenseActivity,

    editExpense,
    removeExpense,

    clearExpenseActionError,
  }
}