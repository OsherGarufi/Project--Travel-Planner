import {
    getCachedTripExpenses,
    setCachedTripExpenses,
} from '../expenseCacheService'
import {
    getTripItineraryCache,
    setTripItineraryCache,
} from './itineraryCache'

function createItineraryItemFromExpense(
  expense,
  existingItem,
  tripId,
) {
  return {
    ...existingItem,

    id:
      expense.itineraryItemId,

    tripId:
      expense.tripId ||
      tripId,

    expenseId:
      expense.id,

    title:
      expense.title,

    description:
      expense.notes ?? null,

    category:
      expense.category,

    itineraryDate:
      expense.itineraryDate ??
      null,

    startTime:
      expense.startTime ??
      null,

    endTime:
      expense.endTime ??
      null,

    referenceUrl:
      expense.referenceUrl ??
      null,

    cost:
      expense.amount,

    currency:
      expense.currency,

    createdAt:
      existingItem?.createdAt ??
      expense.createdAt,

    updatedAt:
      expense.updatedAt ??
      existingItem?.updatedAt ??
      expense.createdAt,
  }
}

function createExpenseFromItineraryItem(
  item,
  existingExpense,
  tripId,
) {
  return {
    ...existingExpense,

    id:
      item.expenseId,

    tripId:
      item.tripId ||
      tripId,

    itineraryItemId:
      item.id,

    category:
      item.category,

    title:
      item.title,

    amount:
      item.cost,

    currency:
      item.currency,

    referenceUrl:
      item.referenceUrl ??
      null,

    notes:
      item.description ??
      null,

    itineraryDate:
      item.itineraryDate ??
      null,

    startTime:
      item.startTime ??
      null,

    endTime:
      item.endTime ??
      null,

    createdAt:
      existingExpense?.createdAt ??
      item.createdAt,

    updatedAt:
      item.updatedAt ??
      existingExpense?.updatedAt ??
      item.createdAt,
  }
}

/**
 * Synchronizes a linked itinerary item after an
 * Expense create/update.
 *
 * If the itinerary cache does not already exist,
 * nothing is created. We never create a partial
 * trip itinerary cache from one Expense.
 */
export function syncItineraryCacheFromExpense(
  userId,
  tripId,
  expense,
) {
  if (
    !userId ||
    !tripId ||
    !expense?.id ||
    !expense?.itineraryItemId
  ) {
    return
  }

  const cachedItems =
    getTripItineraryCache(
      userId,
      tripId,
    )

  if (!cachedItems) {
    return
  }

  const existingItem =
    cachedItems.find(
      (item) =>
        item.id ===
        expense.itineraryItemId,
    )

  const syncedItem =
    createItineraryItemFromExpense(
      expense,
      existingItem,
      tripId,
    )

  const nextItems =
    existingItem
      ? cachedItems.map(
          (item) =>
            item.id ===
            expense.itineraryItemId
              ? syncedItem
              : item,
        )
      : [
          ...cachedItems,
          syncedItem,
        ]

  setTripItineraryCache(
    userId,
    tripId,
    nextItems,
  )
}

/**
 * Synchronizes the itinerary cache after a linked
 * Expense is deleted.
 *
 * deleteLinkedActivity = false:
 * Expense disappears, Activity remains free.
 *
 * deleteLinkedActivity = true:
 * Both Expense and Activity disappear.
 */
export function syncItineraryCacheAfterExpenseDelete(
  userId,
  tripId,
  expense,
  deleteLinkedActivity,
) {
  if (
    !userId ||
    !tripId ||
    !expense?.itineraryItemId
  ) {
    return
  }

  const cachedItems =
    getTripItineraryCache(
      userId,
      tripId,
    )

  if (!cachedItems) {
    return
  }

  if (
    deleteLinkedActivity ===
    true
  ) {
    const nextItems =
      cachedItems.filter(
        (item) =>
          item.id !==
          expense.itineraryItemId,
      )

    setTripItineraryCache(
      userId,
      tripId,
      nextItems,
    )

    return
  }

  if (
    deleteLinkedActivity ===
    false
  ) {
    const nextItems =
      cachedItems.map(
        (item) => {
          if (
            item.id !==
            expense.itineraryItemId
          ) {
            return item
          }

          return {
            ...item,
            expenseId: null,
            cost: null,
            currency: null,
          }
        },
      )

    setTripItineraryCache(
      userId,
      tripId,
      nextItems,
    )
  }
}

/**
 * Synchronizes Expenses cache after an itinerary
 * item create/update/schedule mutation.
 *
 * previousItem is required for Paid -> Free because
 * the updated itinerary response no longer contains
 * the Expense id that was deleted by the backend.
 *
 * If the Expenses cache does not already exist,
 * nothing is created. This avoids building a partial
 * Expenses cache from one itinerary item.
 */
export function syncExpensesCacheFromItineraryItem(
  userId,
  tripId,
  item,
  previousItem = null,
) {
  if (
    !userId ||
    !tripId ||
    !item?.id
  ) {
    return
  }

  const cachedExpenses =
    getCachedTripExpenses(
      userId,
      tripId,
    )

  if (!cachedExpenses) {
    return
  }

  const previousExpenseId =
    previousItem?.expenseId ??
    null

  const currentExpenseId =
    item.expenseId ??
    null

  if (!currentExpenseId) {
    if (!previousExpenseId) {
      return
    }

    const nextExpenses =
      cachedExpenses.filter(
        (expense) =>
          expense.id !==
          previousExpenseId,
      )

    setCachedTripExpenses(
      userId,
      tripId,
      nextExpenses,
    )

    return
  }

  const existingExpense =
    cachedExpenses.find(
      (expense) =>
        expense.id ===
        currentExpenseId,
    )

  const syncedExpense =
    createExpenseFromItineraryItem(
      item,
      existingExpense,
      tripId,
    )

  const expensesWithoutPrevious =
    previousExpenseId &&
    previousExpenseId !==
      currentExpenseId
      ? cachedExpenses.filter(
          (expense) =>
            expense.id !==
            previousExpenseId,
        )
      : cachedExpenses

  const hasCurrentExpense =
    expensesWithoutPrevious.some(
      (expense) =>
        expense.id ===
        currentExpenseId,
    )

  const nextExpenses =
    hasCurrentExpense
      ? expensesWithoutPrevious.map(
          (expense) =>
            expense.id ===
            currentExpenseId
              ? syncedExpense
              : expense,
        )
      : [
          syncedExpense,
          ...expensesWithoutPrevious,
        ]

  setCachedTripExpenses(
    userId,
    tripId,
    nextExpenses,
  )
}

/**
 * Removes the linked Expense from an existing
 * Expenses cache after an itinerary item is deleted.
 */
export function syncExpensesCacheAfterItineraryDelete(
  userId,
  tripId,
  item,
) {
  if (
    !userId ||
    !tripId ||
    !item?.expenseId
  ) {
    return
  }

  const cachedExpenses =
    getCachedTripExpenses(
      userId,
      tripId,
    )

  if (!cachedExpenses) {
    return
  }

  const nextExpenses =
    cachedExpenses.filter(
      (expense) =>
        expense.id !==
        item.expenseId,
    )

  setCachedTripExpenses(
    userId,
    tripId,
    nextExpenses,
  )
}